import copy
import json
import os
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESUME_FILE = os.getenv("RESUME_FILE", str(PROJECT_ROOT / "data" / "resume.json"))

SECTION_ALIASES = {
    "summary": "summary",
    "skill": "skills",
    "skills": "skills",
    "project": "projects",
    "projects": "projects",
    "experience": "experiences",
    "experiences": "experiences",
    "work": "experiences",
    "education": "education",
    "educations": "education",
}

REQUIRED_KEYS = {"summary", "skills", "projects", "experiences", "education"}


def _resume_path():
    return Path(RESUME_FILE)


def _normalize_section(section_name):
    key = str(section_name).strip().lower()
    if key not in SECTION_ALIASES:
        valid = ", ".join(sorted(set(SECTION_ALIASES.values())))
        raise ValueError(f"Unknown resume section '{section_name}'. Valid sections: {valid}.")
    return SECTION_ALIASES[key]


def _next_id(items):
    return max((int(item["id"]) for item in items), default=0) + 1


def _find_by_id(items, item_id, section_name):
    for item in items:
        if int(item["id"]) == int(item_id):
            return item
    raise ValueError(f"No {section_name} entry found with id {item_id}.")


def _validate_string(value, field_name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string.")
    return value.strip()


def _validate_resume_schema(resume):
    if not isinstance(resume, dict):
        raise ValueError("Resume must be a JSON object.")

    missing = REQUIRED_KEYS - set(resume)
    extra = set(resume) - REQUIRED_KEYS
    if missing:
        raise ValueError(f"Resume is missing required keys: {sorted(missing)}.")
    if extra:
        raise ValueError(f"Resume has unsupported keys: {sorted(extra)}.")

    if not isinstance(resume["summary"], str):
        raise ValueError("summary must be a string.")

    _validate_items(
        resume["skills"],
        "skills",
        {"id": int, "name": str, "category": str},
    )
    _validate_items(
        resume["projects"],
        "projects",
        {"id": int, "name": str, "description": str},
    )
    _validate_items(
        resume["education"],
        "education",
        {"id": int, "degree": str, "institution": str, "year": str},
    )
    _validate_items(
        resume["experiences"],
        "experiences",
        {"id": int, "company": str, "role": str, "dates": str, "bullets": list},
    )
    for experience in resume["experiences"]:
        if not all(isinstance(bullet, str) for bullet in experience["bullets"]):
            raise ValueError("experience bullets must be strings.")


def _validate_items(items, section_name, fields):
    if not isinstance(items, list):
        raise ValueError(f"{section_name} must be a list.")

    seen_ids = set()
    for item in items:
        if not isinstance(item, dict):
            raise ValueError(f"Each {section_name} entry must be an object.")
        if set(item) != set(fields):
            raise ValueError(
                f"{section_name} entries must contain exactly these keys: {sorted(fields)}."
            )
        for field, expected_type in fields.items():
            if not isinstance(item[field], expected_type):
                raise ValueError(f"{section_name}.{field} has the wrong type.")
        if item["id"] in seen_ids:
            raise ValueError(f"{section_name} contains duplicate id {item['id']}.")
        seen_ids.add(item["id"])


def get_resume():
    """Return the complete resume JSON."""
    with _resume_path().open("r", encoding="utf-8") as file:
        resume = json.load(file)
    _validate_resume_schema(resume)
    return resume


def save_resume(data):
    """Validate and persist the complete resume JSON."""
    _validate_resume_schema(data)
    with _resume_path().open("w", encoding="utf-8") as file:
        json.dump(data, file, indent=4)
        file.write("\n")


def get_section(section_name):
    """Return one resume section by name."""
    resume = get_resume()
    section = _normalize_section(section_name)
    return copy.deepcopy(resume[section])


def get_summary():
    """Return the current resume summary."""
    return {"summary": get_resume()["summary"]}


def update_summary(new_summary):
    """Replace the resume summary with the provided text."""
    resume = get_resume()
    resume["summary"] = _validate_string(new_summary, "new_summary")
    save_resume(resume)
    return "Summary updated successfully."


def add_skill(skill_name, category="General"):
    """Add a skill with a category."""
    resume = get_resume()
    skill_name = _validate_string(skill_name, "skill_name")
    category = _validate_string(category or "General", "category")

    skills = resume["skills"]
    existing = {
        (skill["name"].strip().lower(), skill["category"].strip().lower())
        for skill in skills
    }
    if (skill_name.lower(), category.lower()) in existing:
        return f"{skill_name} already exists in {category}."

    new_skill = {"id": _next_id(skills), "name": skill_name, "category": category}
    skills.append(new_skill)
    save_resume(resume)
    return f"{skill_name} added successfully with id {new_skill['id']}."


def remove_skill(skill_id):
    """Remove a skill by id."""
    resume = get_resume()
    skill = _find_by_id(resume["skills"], skill_id, "skills")
    resume["skills"] = [item for item in resume["skills"] if item["id"] != skill["id"]]
    save_resume(resume)
    return f"Skill {skill['name']} removed."


def update_skill(skill_id, skill_name="", category=""):
    """Update a skill name and/or category by id."""
    resume = get_resume()
    skill = _find_by_id(resume["skills"], skill_id, "skills")
    if skill_name:
        skill["name"] = _validate_string(skill_name, "skill_name")
    if category:
        skill["category"] = _validate_string(category, "category")
    save_resume(resume)
    return f"Skill {skill_id} updated."


def add_experience(company, role, dates, bullets):
    """Add a work experience entry."""
    resume = get_resume()
    if not isinstance(bullets, list) or not bullets:
        raise ValueError("bullets must be a non-empty list of strings.")
    new_experience = {
        "id": _next_id(resume["experiences"]),
        "company": _validate_string(company, "company"),
        "role": _validate_string(role, "role"),
        "dates": _validate_string(dates, "dates"),
        "bullets": [_validate_string(bullet, "bullet") for bullet in bullets],
    }
    resume["experiences"].append(new_experience)
    save_resume(resume)
    return f"Experience added with id {new_experience['id']}."


def update_experience(experience_id, company="", role="", dates=""):
    """Update company, role, and/or dates for an experience by id."""
    resume = get_resume()
    experience = _find_by_id(resume["experiences"], experience_id, "experiences")
    if company:
        experience["company"] = _validate_string(company, "company")
    if role:
        experience["role"] = _validate_string(role, "role")
    if dates:
        experience["dates"] = _validate_string(dates, "dates")
    save_resume(resume)
    return f"Experience {experience_id} updated."


def remove_experience(experience_id):
    """Remove an experience by id."""
    resume = get_resume()
    experience = _find_by_id(resume["experiences"], experience_id, "experiences")
    resume["experiences"] = [
        item for item in resume["experiences"] if item["id"] != experience["id"]
    ]
    save_resume(resume)
    return f"Experience {experience_id} removed."


def add_experience_bullet(experience_id, bullet):
    """Add a bullet to an experience by id."""
    resume = get_resume()
    experience = _find_by_id(resume["experiences"], experience_id, "experiences")
    experience["bullets"].append(_validate_string(bullet, "bullet"))
    save_resume(resume)
    return f"Bullet added to experience {experience_id}."


def update_experience_bullet(experience_id, bullet_number, bullet):
    """Update a 1-based bullet number for an experience."""
    resume = get_resume()
    experience = _find_by_id(resume["experiences"], experience_id, "experiences")
    index = int(bullet_number) - 1
    if index < 0 or index >= len(experience["bullets"]):
        raise ValueError(f"Experience {experience_id} has no bullet {bullet_number}.")
    experience["bullets"][index] = _validate_string(bullet, "bullet")
    save_resume(resume)
    return f"Bullet {bullet_number} updated for experience {experience_id}."


def remove_experience_bullet(experience_id, bullet_number):
    """Remove a 1-based bullet number from an experience."""
    resume = get_resume()
    experience = _find_by_id(resume["experiences"], experience_id, "experiences")
    index = int(bullet_number) - 1
    if index < 0 or index >= len(experience["bullets"]):
        raise ValueError(f"Experience {experience_id} has no bullet {bullet_number}.")
    removed = experience["bullets"].pop(index)
    save_resume(resume)
    return f"Removed bullet from experience {experience_id}: {removed}"


def replace_experience_bullets(experience_id, bullets):
    """Replace all bullets for an experience by id."""
    resume = get_resume()
    if not isinstance(bullets, list) or not bullets:
        raise ValueError("bullets must be a non-empty list of strings.")
    experience = _find_by_id(resume["experiences"], experience_id, "experiences")
    experience["bullets"] = [_validate_string(bullet, "bullet") for bullet in bullets]
    save_resume(resume)
    return f"Bullets replaced for experience {experience_id}."


def add_education(degree, institution, year):
    """Add an education entry."""
    resume = get_resume()
    new_education = {
        "id": _next_id(resume["education"]),
        "degree": _validate_string(degree, "degree"),
        "institution": _validate_string(institution, "institution"),
        "year": _validate_string(year, "year"),
    }
    resume["education"].append(new_education)
    save_resume(resume)
    return f"Education added with id {new_education['id']}."


def update_education(education_id, degree="", institution="", year=""):
    """Update an education entry by id."""
    resume = get_resume()
    education = _find_by_id(resume["education"], education_id, "education")
    if degree:
        education["degree"] = _validate_string(degree, "degree")
    if institution:
        education["institution"] = _validate_string(institution, "institution")
    if year:
        education["year"] = _validate_string(year, "year")
    save_resume(resume)
    return f"Education {education_id} updated."


def remove_education(education_id):
    """Remove an education entry by id."""
    resume = get_resume()
    education = _find_by_id(resume["education"], education_id, "education")
    resume["education"] = [
        item for item in resume["education"] if item["id"] != education["id"]
    ]
    save_resume(resume)
    return f"Education {education_id} removed."


def add_project(name, description):
    """Add a project entry."""
    resume = get_resume()
    new_project = {
        "id": _next_id(resume["projects"]),
        "name": _validate_string(name, "name"),
        "description": _validate_string(description, "description"),
    }
    resume["projects"].append(new_project)
    save_resume(resume)
    return f"Project added with id {new_project['id']}."


def update_project(project_id, name="", description=""):
    """Update a project by id."""
    resume = get_resume()
    project = _find_by_id(resume["projects"], project_id, "projects")
    if name:
        project["name"] = _validate_string(name, "name")
    if description:
        project["description"] = _validate_string(description, "description")
    save_resume(resume)
    return f"Project {project_id} updated."


def remove_project(project_id):
    """Remove a project by id."""
    resume = get_resume()
    project = _find_by_id(resume["projects"], project_id, "projects")
    resume["projects"] = [
        item for item in resume["projects"] if item["id"] != project["id"]
    ]
    save_resume(resume)
    return f"Project {project_id} removed."
