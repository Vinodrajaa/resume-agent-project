from agents.root_agent import root_agent


if __name__ == "__main__":
    print("Resume Agent project is ready. Run with: adk run .")


__all__ = ["root_agent"]
