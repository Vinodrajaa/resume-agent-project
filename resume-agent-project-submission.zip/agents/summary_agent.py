from google.adk.agents import Agent

from agents.config import MODEL, load_prompt
from tools.resume_repository import get_summary, update_summary


summary_agent = Agent(
    name="summary_agent",
    model=MODEL,
    description="Edits only the resume summary section using tools.",
    instruction=load_prompt("summary_prompt.txt"),
    tools=[get_summary, update_summary],
)
