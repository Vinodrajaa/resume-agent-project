from google.adk.agents import Agent

from agents.config import MODEL, load_prompt
from tools.resume_repository import (
    add_experience,
    add_experience_bullet,
    get_section,
    remove_experience,
    remove_experience_bullet,
    replace_experience_bullets,
    update_experience,
    update_experience_bullet,
)


experiences_agent = Agent(
    name="experiences_agent",
    model=MODEL,
    description="Edits experience entries and bullets using resume tools.",
    instruction=load_prompt("experiences_prompt.txt"),
    tools=[
        get_section,
        add_experience,
        update_experience,
        remove_experience,
        add_experience_bullet,
        update_experience_bullet,
        remove_experience_bullet,
        replace_experience_bullets,
    ],
)
