import os
from pathlib import Path

from dotenv import load_dotenv


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROMPTS_DIR = PROJECT_ROOT / "prompts"

load_dotenv(PROJECT_ROOT / ".env")

MODEL = os.getenv("ADK_MODEL", "gemini-2.5-flash-lite")


def load_prompt(file_name):
    return (PROMPTS_DIR / file_name).read_text(encoding="utf-8").strip()
