from google.adk.agents import Agent

from agents.config import MODEL, load_prompt
from tools.resume_repository import (
    add_education,
    get_section,
    remove_education,
    update_education,
)


education_agent = Agent(
    name="education_agent",
    model=MODEL,
    description="Edits education entries using resume tools.",
    instruction=load_prompt("education_prompt.txt"),
    tools=[get_section, add_education, update_education, remove_education],
)
