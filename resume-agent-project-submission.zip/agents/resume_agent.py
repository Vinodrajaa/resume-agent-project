from google.adk.agents import Agent

from agents.config import MODEL, load_prompt
from agents.educations_agent import education_agent
from agents.experiences_agent import experiences_agent
from agents.projects_agent import projects_agent
from agents.skills_agent import skills_agent
from agents.summary_agent import summary_agent
from tools.resume_repository import get_resume, get_section


resume_agent = Agent(
    name="resume_agent",
    model=MODEL,
    description="Reads the full resume and routes resume edit requests to section agents.",
    instruction=load_prompt("resume_prompt.txt"),
    tools=[get_resume, get_section],
    sub_agents=[
        summary_agent,
        experiences_agent,
        education_agent,
        skills_agent,
        projects_agent,
    ],
)
