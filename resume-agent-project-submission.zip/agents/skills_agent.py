from google.adk.agents import Agent

from agents.config import MODEL, load_prompt
from tools.resume_repository import add_skill, get_section, remove_skill, update_skill


skills_agent = Agent(
    name="skills_agent",
    model=MODEL,
    description="Adds, removes, and recategorizes resume skills using tools.",
    instruction=load_prompt("skills_prompt.txt"),
    tools=[get_section, add_skill, remove_skill, update_skill],
)
