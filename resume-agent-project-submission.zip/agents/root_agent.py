from google.adk.agents import Agent

from agents.config import MODEL, load_prompt
from agents.resume_agent import resume_agent


root_agent = Agent(
    name="unibot",
    model=MODEL,
    description="Unibot greets users, answers general questions, and routes resume edits.",
    instruction=load_prompt("root_prompt.txt"),
    sub_agents=[resume_agent],
)
