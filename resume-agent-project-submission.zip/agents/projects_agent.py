from google.adk.agents import Agent

from agents.config import MODEL, load_prompt
from tools.resume_repository import add_project, get_section, remove_project, update_project


projects_agent = Agent(
    name="projects_agent",
    model=MODEL,
    description="Adds, removes, and edits resume projects using tools.",
    instruction=load_prompt("projects_prompt.txt"),
    tools=[get_section, add_project, update_project, remove_project],
)
