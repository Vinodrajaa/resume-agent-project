# Google ADK Resume Agent Take-Home

Unibot is a small Google ADK multi-agent system for editing a resume JSON with tool calls.

## How to Run

From this project folder:

```powershell
adk run .\unibot "hello"
adk run .\unibot "Add Python to my skills"
adk web .
```

If the `adk` command is not on PATH, use the module entry point:

```powershell
py -m google.adk.cli run --in_memory .\unibot "hello"
py -m google.adk.cli web --session_service_uri memory:// --artifact_service_uri memory:// .
```

The project reads `GOOGLE_API_KEY` from `.env`. The default model is `gemini-2.5-flash-lite`, which supports function calling and is cost-efficient for this task. To change the model, add `ADK_MODEL=<model-name>` to `.env`.

If ADK shows `429 RESOURCE_EXHAUSTED`, the app loaded correctly but the Google API key has hit a model quota. Wait for quota reset, use a Google AI Studio key with available quota, or switch `ADK_MODEL` to another supported Gemini model that has quota on the key.

## How to Change the Resume

Edit this file:

```text
data/resume.json
```

The evaluator can replace that file with another resume as long as it keeps the same schema:

```json
{
  "summary": "string",
  "skills": [{"id": 1, "name": "string", "category": "string"}],
  "projects": [{"id": 1, "name": "string", "description": "string"}],
  "experiences": [
    {
      "id": 1,
      "company": "string",
      "role": "string",
      "dates": "string",
      "bullets": ["string"]
    }
  ],
  "education": [{"id": 1, "degree": "string", "institution": "string", "year": "string"}]
}
```

## Agent Hierarchy

```text
Unibot root agent
└── Resume Agent
    ├── Summary Agent
    ├── Experiences Agent
    ├── Education Agent
    ├── Skills Agent
    └── Projects Agent
```

Unibot greets users, answers general career or Unimad-style resume questions, detects resume-editing intent, and routes resume edits to the Resume Agent.

The Resume Agent calls `get_resume()` first, identifies the target section, maps order words like "first" or "second" to the current resume, and transfers the request to one section agent.

Section agents are responsible for their own section only. They must use tools for edits and must not rewrite the JSON directly.

## Tool List

Read tools:

- `get_resume()`
- `get_section(section_name)`
- `get_summary()`

Summary:

- `update_summary(new_summary)`

Skills:

- `add_skill(skill_name, category)`
- `remove_skill(skill_id)`
- `update_skill(skill_id, skill_name, category)`

Experiences:

- `add_experience(company, role, dates, bullets)`
- `update_experience(experience_id, company, role, dates)`
- `remove_experience(experience_id)`
- `add_experience_bullet(experience_id, bullet)`
- `update_experience_bullet(experience_id, bullet_number, bullet)`
- `remove_experience_bullet(experience_id, bullet_number)`
- `replace_experience_bullets(experience_id, bullets)`

Education:

- `add_education(degree, institution, year)`
- `update_education(education_id, degree, institution, year)`
- `remove_education(education_id)`

Projects:

- `add_project(name, description)`
- `update_project(project_id, name, description)`
- `remove_project(project_id)`

All tools validate the resume schema before saving so the JSON stays valid and keeps the required structure.

## Sample Evaluator Queries

- Make my summary more senior
- Rewrite my summary for leadership roles
- Add a leadership bullet to my first experience
- Add Python to my skills
- Remove my second project
- Improve my first job bullets for impact
- Add a project about an AI chatbot
- Shorten my summary

## Prompt Design

Prompts are stored in `prompts/`. The root prompt focuses on greeting, general answers, and routing. The Resume Agent prompt forces a full-resume read before routing. Section prompts keep each agent inside its section, require tool use for edits, and instruct agents to ask a concise clarification when a target item is ambiguous.
