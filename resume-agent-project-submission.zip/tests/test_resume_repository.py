import json
import shutil
import tempfile
import unittest
from pathlib import Path

from tools import resume_repository as repo


PROJECT_ROOT = Path(__file__).resolve().parents[1]


class ResumeRepositoryTest(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.TemporaryDirectory()
        self.resume_file = Path(self.tmp_dir.name) / "resume.json"
        shutil.copy(PROJECT_ROOT / "data" / "resume.json", self.resume_file)
        self.original_resume_file = repo.RESUME_FILE
        repo.RESUME_FILE = str(self.resume_file)

    def tearDown(self):
        repo.RESUME_FILE = self.original_resume_file
        self.tmp_dir.cleanup()

    def test_read_resume_and_sections(self):
        resume = repo.get_resume()
        self.assertEqual(
            sorted(resume.keys()),
            ["education", "experiences", "projects", "skills", "summary"],
        )
        self.assertIsInstance(repo.get_section("skills"), list)
        self.assertIsInstance(repo.get_section("summary"), str)
        self.assertIsInstance(repo.get_summary()["summary"], str)

    def test_summary_and_skills_edits(self):
        self.assertIn("Summary updated", repo.update_summary("Senior analytics leader."))
        self.assertIn("Tableau added", repo.add_skill("Tableau", "Analytics"))
        self.assertIn("updated", repo.update_skill(1, category="Business Analytics"))
        self.assertIn("removed", repo.remove_skill(2))

        resume = repo.get_resume()
        self.assertEqual(resume["summary"], "Senior analytics leader.")
        self.assertNotIn("SQL", [skill["name"] for skill in resume["skills"]])

    def test_experience_edits(self):
        self.assertIn(
            "added",
            repo.add_experience(
                "XYZ Inc",
                "Analytics Lead",
                "2025-Present",
                ["Led analytics delivery."],
            ),
        )
        self.assertIn("updated", repo.update_experience(1, role="Senior Data Analyst"))
        self.assertIn("Bullet added", repo.add_experience_bullet(1, "Built KPI reporting."))
        self.assertIn(
            "updated",
            repo.update_experience_bullet(1, 1, "Built executive dashboards."),
        )
        self.assertIn("replaced", repo.replace_experience_bullets(1, ["Improved reporting."]))
        self.assertIn("removed", repo.remove_experience(2))

        experiences = repo.get_section("experiences")
        self.assertEqual(len(experiences), 1)
        self.assertEqual(experiences[0]["bullets"], ["Improved reporting."])

    def test_education_and_project_edits(self):
        self.assertIn("Education added", repo.add_education("MS Analytics", "Example University", "2026"))
        self.assertIn("updated", repo.update_education(1, year="2021"))
        self.assertIn("removed", repo.remove_education(2))
        self.assertIn("Project added", repo.add_project("AI Chatbot", "Built an AI resume chatbot."))
        self.assertIn("updated", repo.update_project(1, description="Built sales reporting dashboards."))
        self.assertIn("removed", repo.remove_project(2))

        resume = repo.get_resume()
        self.assertEqual(len(resume["education"]), 1)
        self.assertEqual(len(resume["projects"]), 1)

    def test_saved_json_remains_valid(self):
        repo.add_skill("Looker", "Analytics")
        with self.resume_file.open("r", encoding="utf-8") as file:
            saved = json.load(file)
        self.assertEqual(sorted(saved.keys()), ["education", "experiences", "projects", "skills", "summary"])


if __name__ == "__main__":
    unittest.main()
